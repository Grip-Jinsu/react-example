import { ReactMemoEx } from "../../modules/view"

export const HomeContainer: React.FC = ReactMemoEx(() =>  {
    return (
        <div>
            <h2>Home 입니다.</h2>
        </div>
    )

})
