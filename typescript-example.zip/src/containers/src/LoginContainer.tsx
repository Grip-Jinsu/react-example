import { LoginMain } from "../../components"
import { ReactMemoEx } from "../../modules/view"

export const LoginContainer: React.FC = ReactMemoEx(() =>  {
    return (
        <div>
            <LoginMain />
        </div>
    )
})
