import * as React from 'react';
import Link from '@mui/material/Link';
import Typography from '@mui/material/Typography';
import Title from './Title';

function preventDefault(event: React.MouseEvent) {
  event.preventDefault();
}

export default function Deposits() {
  return (
    <React.Fragment>
      <Title>현재 정산 수익</Title>
      <Typography component="p" variant="h4">
        45,000원
      </Typography>
      <Typography color="text.secondary" sx={{ flex: 1 }}>
        2023년 1월 30일 기준
      </Typography>
      <div>
        <Link color="primary" href="#" onClick={preventDefault}>
          상세 수익 내역 보기
        </Link>
      </div>
    </React.Fragment>
  );
}