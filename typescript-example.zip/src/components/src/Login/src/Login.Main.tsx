
import { ReactMemoEx } from '../../../../modules/view'
import { LoginInput } from "./Login.Input"
import { LoginButton } from "./Login.Button"
import { StyleLoginMainContainer, StyleLoginMainTitle, StyleLoginMainInputContainer } from "./style/Login.Main.style"


export const LoginMain: React.FC = ReactMemoEx(() =>  {
    return (
        <StyleLoginMainContainer>
            <StyleLoginMainTitle>GripONE</StyleLoginMainTitle>
            <StyleLoginMainInputContainer>
                <LoginInput description="이메일" 
                    placeholder="이메일 입력" 
                    type="text" />
                <LoginInput description="패스워드" 
                    placeholder="패스워드 입력" 
                    type="password"/>
                <LoginButton title="로그인"/>
            </StyleLoginMainInputContainer>
        </StyleLoginMainContainer>
    )
})
